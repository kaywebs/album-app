{
    "id": 1768774982059,
    "slug": "test-album",
    "title": "Test Album",
    "artist": "kwebspost",
    "cover": "./assets/waynestreetcovermaybe.png",
    "releaseDate": "2026-01-18",
    "label": "Mental Strain Records",
    "releaseNumber": "MSR-004",
    "description": "",
    "playingSong": "Track3",
    "credits": {
        "Producer": "Tyler Witkowski",
        "Mixer": "Tyler Witkowski",
        "Mastering Engineer": "Tyler Witkowski",
        "Artist": "Tyler Witkowski"
    },
    "artistLinks": {
        "spotify": "",
        "appleMusic": "",
        "youtube": "",
        "bandcamp": ""
    },
    "tracks": [
        {
            "title": "Track1",
            "length": "1:00"
        },
        {
            "title": "Track2",
            "length": "1:00"
        },
        {
            "title": "Track3",
            "length": "1:00"
        },
        {
            "title": "Track4",
            "length": "1:00"
        }
    ]
}